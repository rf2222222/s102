
def hi():
	print 'test2'
