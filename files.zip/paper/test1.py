
def hi():
	print 'test1'
